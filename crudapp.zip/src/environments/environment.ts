// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyC0mFrdRY3NnPbHcVVgIcnkDyrYTZG7OM4",
    authDomain: "bus-ticket-booking-38679.firebaseapp.com",
    databaseURL: "https://bus-ticket-booking-38679.firebaseio.com",
    projectId: "bus-ticket-booking-38679",
    storageBucket: "bus-ticket-booking-38679.appspot.com",
    messagingSenderId: "529395701072",
    appId: "1:529395701072:web:9fe420b645749b65fe8855"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
